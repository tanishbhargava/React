import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useSelector } from 'react-redux';
import {Route, Switch, Redirect, Router} from 'react-router-dom';

import Login from './components/Login/Login';
import Task from './components/Task/Create_Edit';
import Workflow from './components/Workflow/CreateWorkflow';
//import MainHeader from './components/MainHeader/MainHeader';
import history from './components/History/History';
import {authActions} from './store/auth';

function App() {
  const isAuth = useSelector(state => state.auth.isAuthenticated);
  console.log('isAuth : ' + isAuth);
  const dispatch = useDispatch();

  //const [workflowList, setWorkflowList] = useState([]);
  // const [workflowTaskList, setWorkflowTaskList] = useState([{
  //       id: 'T1',
  //       name: 'Task1',
  //       state: 'completed'
  //       },
  //       {
  //         id: 'T2',
  //         name: 'Task2',
  //         state: 'in progress'
  //       },
  //       {
  //         id: 'T3',
  //         name: 'Task3',
  //         state: 'pending'
  //       }
  //     ]);


  // const loginHandler = () => {
  //   if(isAuth){console.log('History : ' + history);
  //     history.push('/workflow')  
  //   }
  // };

  const logoutHandler = () => {
    dispatch(authActions.logout());
  };

  const addNoteHandler = (node) => {
    // setWorkflowTaskList((prevState) => {
    //   return { ...prevState, node};
    // });

  };

  return (
    <React.Fragment>
      {/* <MainHeader isAuthenticated={isLoggedIn} onLogout={logoutHandler} /> */}
      <main>
        <Router history={history}>
          <Switch>
            <Route path='/' exact >
              <Redirect to='/login' />
            </Route>
            <Route path='/login'>
              {!isAuth ? <Login /> : <Workflow />}
            </Route>
            <Route path='/workflow'>
              {isAuth ? <Workflow /> : <Login />}
            </Route>
            <Route path='/task/:id'>
              {isAuth ? <Task /> : <Login />}
            </Route>
          </Switch>
          {/* <Workflow /> */}
          {/* {!isLoggedIn && <Login onLogin={loginHandler} />} */}
          {/* {isLoggedIn && <Home onLogout={logoutHandler} />} */}
        </Router>
      </main>
    </React.Fragment>
  );
}

export default App;
