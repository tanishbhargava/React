import React from 'react';
import { useParams } from 'react-router-dom';
import { useSelector,useDispatch, shallowEqual } from 'react-redux';
import Card from '../../UI/Card/Card';
import classes from './Create_Edit.module.css';
import Task from '../Controls/Task';
import history from '../History/History';

import { workflowListActions } from '../../store/workflowList';
import { workflowTaskListActions } from  '../../store/workflowTaskList';

const Create_Edit = (props) => {
   const params = useParams();
   console.log('workflowid :: ' + params.id);
   const dispatch = useDispatch();
   const workflowList = useSelector(state => state.workflow.nodes, shallowEqual)
   console.log('workflowList :: ' + JSON.stringify(workflowList));
   const selWorkflowList = workflowList.filter(item => item.id.indexOf(params.id) > -1);
   console.log('selWorkflowList :: ' + JSON.stringify(selWorkflowList));
   console.log('selWorkflowList.name : ' + selWorkflowList[0].name);
   document.getElementById('workflow_name').value = selWorkflowList[0].name;

   const workflowTaskList = useSelector((state) => state.task.nodes, shallowEqual);
   console.log('workflowTaskList :: ' + JSON.stringify(workflowTaskList));
   const selWorkflowTaskList = workflowTaskList.filter(item => item.workflowId.indexOf(params.id) > -1);
   console.log('selWorkflowTaskList :: ' + JSON.stringify(selWorkflowTaskList));
   //const workflowCount = Object.keys(workflowList).length + 1;
   const taskCount = Object.keys(workflowTaskList).length + 1;
   const taskNameCount = Object.keys(selWorkflowTaskList).length + 1;
   //console.log('workflowList : ' + workflowCount);
   console.log('workflowTaskList : ' + taskCount);
   
    const backHandler = () => {
        history.push('/workflow');
    };

    const addNodeHandler = () => {
        let taskId = 'T' + taskCount;
        let taskName = 'Task' + taskNameCount;
        let state = 'pending';
        dispatch(workflowTaskListActions.addNode({id: taskId, name: taskName, workflowId: params.id, status: state}));
   };

   const deleteNodeHandler = () => {
    let taskId = 'T' + Object.keys(workflowTaskList).length;
    dispatch(workflowTaskListActions.removeNode({id:taskId, workflowId: params.id}));
   };

   const EditWorkflowNameHandler = () => {
    const workflowName = document.getElementById("workflow_name").value;
    dispatch(workflowListActions.EditWorkflowName({id: params.id, name: workflowName}));
   }
   
   return (
    <Card className={classes.workflow}>
        <div>
            <div className={classes.control}>
                <input 
                    type="text" 
                    id="workflow_name" 
                    placeholder='WORKFLOW NAME'
                    // value={enteredWorkflowName}
                    // onChange={WorkFlowChangeHandler}
                    // onBlur={validateWorkflowHandler}
                />
                {/* <div className={classes.actions}> */}
                <span className={classes.span}>
                    <button type="button" className={classes.btn_purple}>
                        Shuffle
                    </button>
                    <button type="button" className={classes.btn_red} onClick={deleteNodeHandler}>
                        Delete
                    </button>
                    <button type="button" className={classes.btn_green} onClick={addNodeHandler}>
                        Add Note
                    </button>
                    <button type="button" className={classes.btn_green} onClick={EditWorkflowNameHandler}>
                        Save
                    </button>
                    <button type="button" className={classes.btn_blue} onClick={backHandler}>
                        Back
                    </button>
                </span>
                {/* </div> */}
                
            </div>
            <div>
                <hr className={classes.hr} />
            </div>
            {selWorkflowTaskList.map((task) => (
                <Task key={task.id} id={task.id} name={task.name} workflowId={task.workflowId} class={task.state} />
            ))}


            {/* <Task id='T1' name='Task1' class="checkmark_green" />
            <Task id='T2' name='Task2' class="checkmark_blue" />
            <Task id='T3' name='Task3' class="checkmark_grey"/> */}
            
                {/* <div className={classes.div_textarea}>
                    <textarea id="w3review" name="w3review" rows="20" cols="25" className={classes.textarea} />
                    <span className={classes.checkmark}>
                        <div className={classes.checkmark_greencircle}></div>
                        <div className={classes.checkmark_stem}></div>
                        <div className={classes.checkmark_kick}></div>
                    </span>
                </div>
                <div className={classes.div_textarea}>
                    <textarea id="w3review1" name="w3revie2" rows="20" cols="25" className={classes.textarea} />
                    <span className={classes.checkmark}>
                        <div className={classes.checkmark_bluecircle}></div>
                        <div className={classes.checkmark_stem}></div>
                        <div className={classes.checkmark_kick}></div>
                    </span>
                </div>
                <div className={classes.div_textarea}>
                    <textarea id="w3review2" name="w3revie2" rows="20" cols="25" className={classes.textarea} />
                    <span className={classes.checkmark}>
                        <div className={classes.checkmark_greycircle}></div>
                        <div className={classes.checkmark_stem}></div>
                        <div className={classes.checkmark_kick}></div>
                    </span>
                </div> */}
                    
        </div>
    </Card>
   ); 
}; 

export default Create_Edit;