import React, { useState }  from 'react';
import {  useSelector, useDispatch } from 'react-redux';
import Card from '../../UI/Card/Card';
import classes from './Workflow.module.css';
import Input from './input';
import history from '../History/History';
import {workflowListActions} from '../../store/workflowList';
import {workflowTaskListActions} from '../../store/workflowTaskList';

const Workflow = (props) => {
    const dispatch = useDispatch();
    const workflowTaskList = useSelector((state) => state.task.nodes);
    const [isShown, setIsShown] = useState(false);
    let checkGreen = false;
    let checkGrey = false;
    let state = '';
    let workflowState = true;

    switch(props.class) {
        case 'pending':
            checkGrey = true;
            state = 'PENDING';
          break;
        default:
            checkGreen = true;
            state = 'COMPLETED';
      }

      const deleteWorkflowHandler = (workflowId) => {console.log('workflowId : ' + workflowId);
        dispatch(workflowListActions.removeNode({id: workflowId}));
        dispatch(workflowTaskListActions.removeNode_Worklfow({workflowId: workflowId}));
      };

      const editWorkflowHandler = (workflowId) => {console.log('editWorkflowHandler - workflowId :: ' + workflowId);
        history.push('/task/' + workflowId);
      };

        const changeWorkflowStateHandler = (workflowId, status) => {
          console.log('changeWorkflowStateHandler :: workflowId : ' + workflowId);
          const selWorkflowTaskList = workflowTaskList.filter(item => item.workflowId.indexOf(workflowId) > -1);
          console.log('changeWorkflowStateHandler :: selWorkflowTaskList ::' + JSON.stringify(selWorkflowTaskList))
         console.log('Object.keys(selWorkflowTaskList).length : ' + Object.keys(selWorkflowTaskList).length);
        // To set workflow values
        if(Object.keys(selWorkflowTaskList).length > 0){
            for (let value of Object.values(selWorkflowTaskList)) {
                console.log('value : ' + value.state);
                if(value.state !== 'completed'){
                    workflowState = false;
                }
            }
        
            console.log('workflowState : ' + workflowState);
            if(workflowState){
                dispatch(workflowListActions.changeState({id: workflowId, status: status}));
            }
        }
      };

    return (
        <Card className={classes.task}>
            <div onMouseEnter={() => setIsShown(true)} onMouseLeave={() => setIsShown(false)}>
            <div className={classes.checkmark_Div}>
                {isShown && (<span className={classes.checkmarkDelete} onClick={() => deleteWorkflowHandler(props.id)}>
                        <div className={classes.checkmarkDelete_redcircle}></div>
                        {/* <div className={classes.checkmarkDelete_stem}></div>
                        <div className={classes.checkmarkDelete_kick}></div> */}
                    </span>)}
                </div>
                <div className={classes.div_textarea}>

                <Input id="t1" placeholder={props.name} />
                <div>
                    <p className={classes.p_status} onClick={() => editWorkflowHandler(props.id)}>{state}</p>
                    <span className={classes.checkmark}  onClick={() => changeWorkflowStateHandler(props.id, props.class)}>
                    {checkGreen && <div className={classes.checkmark_greencircle}></div>}
                    {checkGrey && <div className={classes.checkmark_greycircle}></div>}
                        {/* <div className={classes.checkmark_greencircle}></div> */}
                        {/* <div className={classes.checkmark_bluecircle}></div>
                        <div className={classes.checkmark_greycircle}></div> */}
                        <div className={classes.checkmark_stem}></div>
                        <div className={classes.checkmark_kick}></div>
                    </span>
                </div>
                {/* <textarea id={props.id} name={props.name}  rows="17" cols="25" 
                className={classes.textarea} /> */}
                
                </div>
            </div>
        </Card>
    );
};

export default Workflow;