import React from 'react';
import { useSelector,useDispatch, shallowEqual } from 'react-redux';
//import { useParams } from 'react-router-dom';
import Card from '../../UI/Card/Card';
import classes from './Task.module.css';
import Input from './input';
import { taskStatusActions } from  '../../store/taskStatus';
import { workflowTaskListActions } from  '../../store/workflowTaskList';

const Task = (props) => {
    //const params = useParams();
    const dispatch = useDispatch();
    const workflowTaskStatus = useSelector(state => state.taskStatus.status);
    console.log('workflowTaskStatus " '+ workflowTaskStatus);

    console.log(props);
    let checkGreen = false;
    let checkBlue = false;
    let checkGrey = false;
    
    switch(props.class) {
        case 'in progress':
          checkBlue = true;
          break;
        case 'pending':
          checkGrey = true;
          break;
        default:
          checkGreen = true;
      }

      const changeStatusHandler = (status, id, workflowId) => {console.log('aaya : '+ status + id + workflowId);
        switch(status) {
            case 'pending':
                checkBlue = true; //sets it in-progress 
                dispatch(taskStatusActions.changeState({status: 'in progress'}));
                dispatch(workflowTaskListActions.updateNode({id: id, workflowId: workflowId, status: 'in progress'}));
                break;
            case 'in progress':
                checkGreen = true; //sets it complete
                dispatch(taskStatusActions.changeState({status: 'completed'}));
                dispatch(workflowTaskListActions.updateNode({id: id, workflowId: workflowId, status: 'completed'}));
              break;
            case 'complete':
                checkGrey = true; //sets it complete
                dispatch(taskStatusActions.changeState({status: 'pending'}));
                dispatch(workflowTaskListActions.updateNode({id: id, workflowId: workflowId, status: 'pending'}));
              break;   
          }
        };
    
    return (
        <Card className={classes.task}>
            <div className={classes.checkmark_Div} onClick={() => changeStatusHandler(props.class, props.id, props.workflowId )}>
                <span className={classes.checkmark}>
                    {checkGreen && <div className={classes.checkmark_greencircle}></div>}
                    {checkBlue && <div className={classes.checkmark_bluecircle}></div>}
                    {checkGrey && <div className={classes.checkmark_greycircle}></div>}
                        <div className={classes.checkmark_stem}></div>
                        <div className={classes.checkmark_kick}></div>
                </span>
            </div>
            <div className={classes.div_textarea}>
                <Input id="t1" placeholder={props.name} />
                <textarea id={props.id} name={props.name}  rows="17" cols="25" 
                className={classes.textarea} />
                {/* <span className={classes.checkmark}>
                {checkGreen && <div className={classes.checkmark_greencircle}></div>}
                {checkBlue && <div className={classes.checkmark_bluecircle}></div>}
                {checkGrey && <div className={classes.checkmark_greycircle}></div>}
                    <div className={classes.checkmark_stem}></div>
                    <div className={classes.checkmark_kick}></div>
                </span> */}
            </div>
        </Card>
    );
};

export default Task;