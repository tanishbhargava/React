import React from 'react';

import classes from './Input.module.css';

const Input = (props) => {
    return (
        <div className={classes.control}>
            <input 
                type="text" 
                id={props.taskId} 
                placeholder={props.placeholder}
                // value={enteredWorkflowName}
                // onChange={WorkFlowChangeHandler}
                // onBlur={validateWorkflowHandler}
            />
        </div>
    );
};

export default Input;