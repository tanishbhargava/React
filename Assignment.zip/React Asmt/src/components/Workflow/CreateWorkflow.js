import React, { useState } from 'react';
import {  useSelector,useDispatch } from 'react-redux';
import Card from '../../UI/Card/Card';
import classes from './CreateWorkflow.module.css';
import WorkflowCTRL from '../Controls/Workflow';
import history from '../History/History';
import {workflowListActions} from '../../store/workflowList';
import { workflowTaskListActions } from  '../../store/workflowTaskList';

const CreateWorkflow = () => {
    // set value for default selection
    const [selectedValue, setSelectedValue] = useState("filter");
    const [selectedName, setSelectedName] = useState("");
    const dispatch = useDispatch();
    const workflowList = useSelector(state => state.workflow.nodes)
    let workflowCount = Object.keys(workflowList).length;
    //const selWorkflowTaskList = workflowTaskList.filter(item => item.workflowId.indexOf(params.id) > -1);
    const workflowTaskList = useSelector((state) => state.task.nodes);
    console.log('CreateWorkflow::workflowTaskList :: ' + JSON.stringify(workflowTaskList));
        
    let workflowListTemplate;

    //To show and filter workflow
    const workflowTemplateHandler = () => {
    let selWorkflowList
    if(selectedValue === 'filter' || selectedValue === 'all'){
        selWorkflowList = workflowList;
        console.log('workflowTemplateHandler : condition : selWorkflowList :: ' + JSON.stringify(selWorkflowList));
    }
    else{
        selWorkflowList = workflowList.filter(item => item.state === selectedValue);
    }
    const workflowCount = Object.keys(selWorkflowList).length;
    console.log('workflowTemplateHandler : workListCount :: ' + workflowCount);
    console.log('workflowTemplateHandler : selWorkflowList :: ' + JSON.stringify(selWorkflowList));
        if (workflowCount > 0 || typeof selWorkflowList !== "undefined") {
            workflowListTemplate = selWorkflowList.map((workflow, index) => (
                <WorkflowCTRL key={index} id={workflow.id} name={workflow.name} class={workflow.state} />
            ))
        } else {
            workflowListTemplate = <li> No Workflow Found </li>;
        }
    };

    workflowTemplateHandler();
    // if (workflowCount > 0 || typeof workflowList === "undefined") {
    //     workflowListTemplate = workflowList.map((workflow, index) => (
    //         <WorkflowCTRL key={index} id={workflow.id} name={workflow.name} class={workflow.state} />
    //     ))

    // } else {
    //     workflowListTemplate = <li> No Workflow Found </li>;
    // }
    console.log('workflowListTemplate : ' + workflowListTemplate);
    console.log('workflowListCount : ' + workflowCount);
    workflowCount = workflowCount + 1;
    console.log('workflowListCount : ' + workflowCount);

    const createWorkflowHandler = () => {
        //history.push('/task');
        let workflowId = 'W' + workflowCount;
        console.log('workflow_name : ' + document.getElementById("workflow_name").value);
        let workflowName = document.getElementById("workflow_name").value;
        let state = 'pending';
        dispatch(workflowListActions.addNode({id: workflowId, name: workflowName, state: state}));
        //history.push('/workflow');
    };

    const worklfowFilterHandler = (e) => {
        const selectedValue = document.getElementById("filter").value;
        console.log('selectedValue : ' + selectedValue);
        setSelectedValue(selectedValue);
               
    };

    const WorkFlowChangeHandler = () => {
        const enteredValue = document.getElementById("workflow_name").value;
        console.log('WorkFlowChangeHandler :: enteredValue : ' + enteredValue);
        const selWorkflowList = workflowList.filter(item => item.name === enteredValue);
        //const state = selWorkflowList[0].state;
        //console.log('WorkFlowChangeHandler :: selWorkflowList[0].state :' + selWorkflowList[0].state);
        setSelectedName(enteredValue);
        //document.getElementById("filter").value = state;

        const workflowCount = Object.keys(selWorkflowList).length;
        console.log('WorkFlowChangeHandler : workListCount :: ' + workflowCount);
        console.log('WorkFlowChangeHandler : selWorkflowList :: ' + JSON.stringify(selWorkflowList));
            if (workflowCount > 0 || typeof selWorkflowList !== "undefined") {
                workflowListTemplate = selWorkflowList.map((workflow, index) => (
                    <WorkflowCTRL key={index} id={workflow.id} name={workflow.name} class={workflow.state} />
                ))
            } else {
                workflowListTemplate = <li> No Workflow Found </li>;
            }
    };

   return (
    <Card className={classes.workflow}>
        <div>
            <div className={classes.control}>
                <input 
                    type="text" 
                    id="workflow_name" 
                    placeholder='Search Workflows'
                    // value={enteredWorkflowName}
                    //onChange={WorkFlowChangeHandler}
                    // onBlur={validateWorkflowHandler}
                />
                <select className={classes.dropdown} id='filter' name="filter" onChange={worklfowFilterHandler} value={selectedValue.vlaue}>
                    <option value="filter">Filter</option>
                    <option value="all">All</option>
                    <option value="completed">Completed</option>
                    <option value="pending">Pending</option>
                </select>
                {/* <Select
                    className={classes.dropdown}
                    placeholder="Select Option"
                    value={data.filter(obj => selectedValue.includes(obj.value))} // set selected values
                    options={data} // set list of the data
                    onChange={worklfowFilterHandler} // assign onChange function
                    isClearable
                /> */}
                {/* <select name="filter" id="filter" onChange={worklfowFilterHandler}>
                    <option value="all">All</option>
                    <option value="completed">Completed</option>
                    <option value="pending">Pending</option>
                </select> */}
                {/* <button type="button" className={classes.btn_white} onClick={worklfowFilterHandler}>
                        Filter
                </button> */}
                <div className={classes.actions}>
                    <button type="button" className={classes.btn_green} onClick={createWorkflowHandler}>
                        + Create Workflow
                    </button>
                </div>
                
            </div>
            <div>
                <hr className={classes.hr} />
            </div>
            {/* {workflowList.map((workflow) => (
                <WorkflowCTRL key={workflow.id} id={workflow.id} name={workflow.name} class={workflow.state} />
            ))} */}
            {workflowListTemplate}

            {/* <WorkflowCTRL id='W1' name='Workflow1' class="checkmark_green" />
            <WorkflowCTRL id='W2' name='Workflow1' class="checkmark_blue" />
            <WorkflowCTRL id='W3' name='Workflow1' class="checkmark_grey"/> */}
            
                    
        </div>  
    </Card>
   ); 
}; 

export default CreateWorkflow;