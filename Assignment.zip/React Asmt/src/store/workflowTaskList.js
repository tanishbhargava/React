import { createSlice } from '@reduxjs/toolkit';

// const initialWorkflowTaskListState = {
//     nodes:[{
//         id: 'T1',
//         name: 'Task1',
//         workflowId: 'W1',
//         state: 'completed'
//     }]
// };

const initialWorkflowTaskListState = {nodes:[]};

const workflowTaskListSlice = createSlice({
    name:'workflowTaskList',
    initialState: initialWorkflowTaskListState,
    reducers: {
        addNode(state, action){console.log('Task action : ' + action);
            state.nodes.push({
                id: action.payload.id,
                name: action.payload.name,
                workflowId: action.payload.workflowId,
                state: action.payload.status
            })    
        },
        updateNode(state, action){
            //     state.nodes.push({
            //     id: action.payload.id,
            //     name: action.payload.name,
            //     workflowId: action.payload.workflowId,
            //     state: action.payload.status
            // })

            return { 
                ...state, 
                nodes: state.nodes.map(
                    (node, i) => (node.id === action.payload.id && node.workflowId === action.payload.workflowId)
                     ? {...node, state: action.payload.status} : node
                )
             }
            
        },
        removeNode(state, action){console.log('action.payload.id : ' + action.payload.id);
        console.log('action.payload.workflowId : ' + action.payload.workflowId);
            //return state.filter(({ id }) => id !== action.payload.id); 
            //return state.nodes.filter(node => node.id !== action.payload.id);  
            //return state.nodes.filter( id  => id !== action.payload.id);

            const newNodes = state.nodes.filter(node => node.id !== action.payload.id && node.workflowId === action.payload.workflowId);
            state.nodes = newNodes;
            
        },
        removeNode_Worklfow(state, action){
        console.log('removeNode_Worklfow :: action.payload.workflowId : ' + action.payload.workflowId);
            //return state.filter(({ id }) => id !== action.payload.id); 
            //return state.nodes.filter(node => node.id !== action.payload.id);  
            //return state.nodes.filter( id  => id !== action.payload.id);

            const newNodes = state.nodes.filter(node => node.workflowId !== action.payload.workflowId);
            state.nodes = newNodes;
            
        },
    },
});

export const workflowTaskListActions = workflowTaskListSlice.actions;

export default workflowTaskListSlice.reducer;