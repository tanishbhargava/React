import { configureStore } from '@reduxjs/toolkit';
import authReducer from './auth';
import workflowListReducer from './workflowList';
import workflowTaskListReducer from './workflowTaskList';
import taskStatusReducer from './taskStatus'; 

const store = configureStore({
    reducer: {auth: authReducer, workflow: workflowListReducer, task: workflowTaskListReducer, taskStatus: taskStatusReducer},
});

export default store;
