import { createSlice } from '@reduxjs/toolkit';

// const initialWorkflowListState = {
//     nodes:[{
//         // id: 'W1',
//         // name: 'Workflow1',
//         // state: 'completed'
//     }]
// };

const initialWorkflowListState = {nodes:[]};

const workflowListSlice = createSlice({
    name:'workflowList',
    initialState: initialWorkflowListState,
    reducers: {
        addNode(state, action){console.log('Workflow action : ' + JSON.stringify(action.payload));
            console.log('state.nodes : ' + state.nodes)
            //if (typeof state.nodes !== "undefined") {
            state.nodes.push({
                id: action.payload.id,
                name: action.payload.name,
                state: action.payload.state
            })  
            //}
            // else{
            //     console.log('state : ' + state);
            //     state = {nodes:[]};
            //     console.log('state : ' + state);
            //     console.log('state.nodes : ' + state.nodes);
            //     return state.nodes.push({
            //         id: action.payload.id,
            //         name: action.payload.name,
            //         state: action.payload.state
            //     })
            //     console.log('state.nodes : ' + JSON.stringify(state.nodes))
            // }  
        },
        removeNode(state, action){console.log('action.payload.id : ' + action.payload.id);
            //return state.filter(({ id }) => id !== action.payload.id); 
            //return state.nodes.filter(node => node.id !== action.payload.id);  
            //return state.nodes.filter( id  => id !== action.payload.id);

            const newNodes = state.nodes.filter(node => node.id !== action.payload.id);
            state.nodes = newNodes;
            
        },
        EditWorkflowName(state, action){console.log('action.payload.id : ' + action.payload.id);
            const nodeIdx = state.nodes.findIndex(t => t.id === action.payload.id);
            state.nodes[nodeIdx].name = action.payload.name;
        },
        changeState(state, action){console.log('action.payload.id : ' + action.payload.id);
            const nodeIdx = state.nodes.findIndex(t => t.id === action.payload.id);
            if(action.payload.status === 'pending'){
                state.nodes[nodeIdx].state = 'completed';
            }
            else{
                state.nodes[nodeIdx].state = 'pending';
            }
            
            // const nodes = state.nodes;
            // console.log('nodes : ' + JSON.stringify(nodes));
            // console.log('Nodes Count : ' + nodes.length);
            // const nodeIdx = nodes.findIndex(t => t.id === action.payload.id);
            // console.log('nodeIdx : ' + nodeIdx);
            // const nodeObj = nodes[nodeIdx];
            // console.log('nodeObj : ' + JSON.stringify(nodeObj));
            // let status;
            // if(action.payload.status === 'pending'){
            //     status = 'completed';
            // }
            // else{
            //     status = 'pending';
            // }
            // const newNodeObj = { ...nodeObj, state: status };
            // console.log('newNodeObj : ' + JSON.stringify(newNodeObj));
            // // console.log('nodes[0] : ' + JSON.stringify(nodes[nodeIdx - 1]));
            // console.log('nodes.slice(0, 1) : ' + JSON.stringify(nodes.slice(0, 2)));
            // let head = [];
            // if(nodeIdx - 1 === 0){
            //     head.push(nodes[nodeIdx - 1]);
            // }
            // else{
            //     head = nodes.slice(0, nodeIdx);
            // }
            
            // //const head = nodes.slice(nodeIdx - 1);
            // console.log('head : ' + JSON.stringify(head));
            // const tail = nodes.slice(nodeIdx + 1, nodes.length);
            // console.log('tail : ' + JSON.stringify(tail));
            
            // //let newNodes;
            // if(nodes.length === 1 || nodes.length > 2){
            //     const newNodes = [...head, newNodeObj, ...tail];
            //     state.nodes = newNodes;
            // }
            // else if(nodes.length === 2) {
            //     if(tail.length > 0 && head.length > 0  && newNodeObj.id === head[0].id){
            //         const newNodes = [newNodeObj, ...tail];
            //         state.nodes = newNodes;
            //     }
            //     else if(tail.length > 0 && head.length === 0){
            //         const newNodes = [newNodeObj, ...tail];
            //         state.nodes = newNodes;
            //     }
            //     else if(tail.length === 0){
            //         const newNodes = [...head, newNodeObj];
            //         state.nodes = newNodes;
            //     }
            //     // if(tail.length > 0  && newNodeObj.id !== tail[0].id && newNodeObj.id !== head[0].id){console.log('else');
            //     //     const newNodes = [...head, newNodeObj];
            //     //     state.nodes = newNodes;
            //     // }
            // }
            // else if(nodes.length > 2) {
            //     //if(tail.length > 0  && newNodeObj.id === head[0].id){console.log('if 1');
            //         const newNodes = [...head, newNodeObj, ...tail];
            //         state.nodes = newNodes;
            // }
            // //console.log('newNodes : ' + JSON.stringify(newNodes));
            // //state.nodes = newNodes;
        },
    },
});

export const workflowListActions = workflowListSlice.actions;

export default workflowListSlice.reducer;