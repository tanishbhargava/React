import { createSlice } from '@reduxjs/toolkit';

const initialTaskStatus = {
  status: 'pending',
};

const taskStatusSlice = createSlice({
  name: 'taskStatus',
  initialState: initialTaskStatus,
  reducers: {
    changeState(state, action) {
        switch(action.payload.status) {
            case 'pending':
                state.status = 'pending';
                break;
            case 'in progress':
                state.status = 'in progress';
              break;
            case 'complete':
                state.status = 'complete';
              break;   
          }        
    },
    
  },
});

export const taskStatusActions = taskStatusSlice.actions;

export default taskStatusSlice.reducer;